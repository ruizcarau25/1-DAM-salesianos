package ejercicio03;

public class Motocicleta extends VehiculoMotor {

	private double cilindrada;

	public Motocicleta(int tipoEmision, double cilindrada) {
		super(tipoEmision);
		this.cilindrada = cilindrada;
	}

	
	public double calcularImpuestoFinal(double porcenMoto, double porcenCoche) {
		
		return super.calcularImpuestoFinal(porcenMoto, porcenCoche) + (cilindrada*porcenMoto/100);
		
	}
	
	
	
}
