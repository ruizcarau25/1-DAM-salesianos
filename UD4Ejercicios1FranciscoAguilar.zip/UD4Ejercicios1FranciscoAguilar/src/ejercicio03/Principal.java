package ejercicio03;

public class Principal {

	public static void main(String[] args) {
		
		/*
		 * Los vehículos a motor pagan un determinado impuesto de circulación. Para
		 * todos los vehículos a motor, la cantidad a pagar depende de la categoría de
		 * emisiones contaminantes (cero emisiones, ECO, tipo B y tipo C). Crear un
		 * programa para calcular la cantidad que debe pagar un vehículo dependiendo de
		 * sus características. (Los vehículos a motor pueden ser motocicletas, coches y
		 * furgonetas).
		 * 
		 * El impuesto se calcula con la cantidad fija cuyo valor depende del tipo de
		 * emisiones por el simple hecho de ser un vehículo con motor más:
		 * 
		 * - El 60 % de la cilindrada en el caso de las motocicletas. - Otra cantidad
		 * fija a las furgonetas por ser transporte de mercancías. - El 25 % de la
		 * potencia en el caso de los coches.
		 * 
		 * La jerarquía de clases no tiene mucho sentido en este ejemplo, pero está
		 * puesto para reescribir métodos. Probar todo en un main sencillo.
		 * 
		 */
		
		double porcenMoto = 20, porcenCoche = 40;
		
		Motocicleta moto = new Motocicleta(1, 200);
		Coche coch = new Coche(2, 150);
		Furgoneta furgo1 = new Furgoneta(3, 100);
		Furgoneta furgo2 = new Furgoneta(4, 100);
		
		System.out.println("Bienvenido al programa para calcular el impuesto final que paga un vehículo.\n");
		
		System.out.println(moto.calcularImpuestoFinal(porcenMoto, porcenCoche));
		System.out.println(coch.calcularImpuestoFinal(porcenMoto, porcenCoche));
		System.out.println(furgo1.calcularImpuestoFinal(porcenMoto, porcenCoche));
		System.out.println(furgo2.calcularImpuestoFinal(porcenMoto, porcenCoche));
		
	}

}
