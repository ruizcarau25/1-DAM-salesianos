package ejercicio03;

public class VehiculoMotor {

	private int tipoEmision;  //1 -cero emisiones  2- ECO  3-tipo B  4-tipo C
	
	public VehiculoMotor(int tipoEmision) {
		
		this.tipoEmision = tipoEmision;
		
	}
	
	
	public int getTipoEmision() {
		return tipoEmision;
	}




	public void setTipoEmision(int tipoEmision) {
		this.tipoEmision = tipoEmision;
	}


	public double calcularImpuestoFinal(double porcenMoto, double porcenCoche) {
		
		double impuestoFinal = 0;
		
		switch(tipoEmision) {
		
			case 1:
				//impuestoBaseCero
				impuestoFinal = 100;
				
			break;
			
			case 2:
				//impuestoBaseECO
				impuestoFinal = 200;
				
			break;
			
			case 3:
				//impuestoBaseTipoB
				impuestoFinal = 300;
				
			break;
			
			case 4:
				//impuestoBaseTipoC
				impuestoFinal = 400;
				
			break;
			
		}
		
		return impuestoFinal;
		
	}
	
}
