package ejercicio03;

public class Furgoneta extends VehiculoMotor {

	private double precioFijo;

	public Furgoneta(int tipoEmision, double precioFijo) {
		super(tipoEmision);
		this.precioFijo = precioFijo;
	}
	
	public double calcularImpuestoFinal(double porcenMoto, double porcenCoche) {
		
		return super.calcularImpuestoFinal(porcenMoto, porcenCoche) + precioFijo;
		
	}
	
}
