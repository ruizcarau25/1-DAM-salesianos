package ejercicio03;

public class Coche extends VehiculoMotor {

	private double potencia;

	public Coche(int tipoEmision, double potencia) {
		super(tipoEmision);
		this.potencia = potencia;
	}
	
	public double calcularImpuestoFinal(double porcenMoto, double porcenCoche) {
		
		return super.calcularImpuestoFinal(porcenMoto, porcenCoche) + (potencia*porcenCoche/100);
			
	}
	
}
