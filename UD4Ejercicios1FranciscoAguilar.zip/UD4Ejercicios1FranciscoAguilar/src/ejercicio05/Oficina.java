package ejercicio05;

import java.util.Arrays;

public class Oficina {

	Empleado [] listaEmpleados;

	//-----Constructor-----
	
	public Oficina(Empleado[] listaEmpleados) {
		super();
		this.listaEmpleados = listaEmpleados;
	}

	//-----Getters and setters----
	
	public Empleado[] getListaEmpleados() {
		return listaEmpleados;
	}

	public void setListaEmpleados(Empleado[] listaEmpleados) {
		this.listaEmpleados = listaEmpleados;
	}

	//-----To String-----
	
	@Override
	public String toString() {
		return "Oficina [listaEmpleados=" + Arrays.toString(listaEmpleados) + "]";
	}
	
	//-----Métodos-----
	
	public double calcularSueldoEmpleado (Empleado e) {
		
		return 0;
		
	}
	
	public double calcularGastado () {
		
		double gasto = 0;
		
		for (int i = 0; i < listaEmpleados.length && listaEmpleados[i] != null; i++) {
			
			gasto += calcularSueldoEmpleado(listaEmpleados[i]);
			
		}
		
		return gasto;
		
	}
	
}
