package ejercicio05;

public class Gerente extends Empleado {

	private double impuestos;

	//-----Constructor-----
	
	public Gerente(String nombre, String apellidos, double sueldoBase, int numEmpleado, double impuestos) {
		super(nombre, apellidos, sueldoBase, numEmpleado);
		this.impuestos = impuestos;
	}

	public Gerente(String nombre, String apellidos, double sueldoBase, int numEmpleado) {
		super(nombre, apellidos, sueldoBase, numEmpleado);
	}

	//-----Getters and setters-----
	
	public double getImpuestos() {
		return impuestos;
	}

	public void setImpuestos(double impuestos) {
		this.impuestos = impuestos;
	}

	//-----To String-----
	
	@Override
	public String toString() {
		return super.toString() + "Gerente [impuestos=" + impuestos + "]";
	}
	
	//-----Métodos-----
	
	public double calcularSueldoFinal () {
		
		return getSueldoBase() - getSueldoBase()*impuestos/100;
		
	}
	
}
