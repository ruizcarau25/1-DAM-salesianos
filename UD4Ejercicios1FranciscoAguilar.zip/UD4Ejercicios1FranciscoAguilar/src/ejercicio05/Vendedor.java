package ejercicio05;

public class Vendedor extends Empleado{

	private int cantVentas;
	private double incentivo;
	
	//-----Constructor-----

	public Vendedor(String nombre, String apellidos, double sueldoBase, int numEmpleado, int cantVentas) {
		super(nombre, apellidos, sueldoBase, numEmpleado);
		this.cantVentas = cantVentas;
	}

	public Vendedor(String nombre, String apellidos, double sueldoBase, int numEmpleado) {
		super(nombre, apellidos, sueldoBase, numEmpleado);
	}

	//-----Getters and setters-----

	public int getCantVentas() {
		return cantVentas;
	}

	public void setCantVentas(int cantVentas) {
		this.cantVentas = cantVentas;
	}

	public double getIncentivo() {
		return incentivo;
	}

	public void setIncentivo(double incentivo) {
		this.incentivo = incentivo;
	}

	//-----To String-----

	@Override
	public String toString() {
		return super.toString() + "Vendedor [cantVentas=" + cantVentas + ", incentivo=" + incentivo + "]";
	}
	
	//-----Métodos-----

	public double calcularIncentivo () {
		
		return getSueldoBase() + cantVentas/100;
		
	}
	
}
