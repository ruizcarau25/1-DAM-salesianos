package ejercicio01;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {
		
		/*
		 * Crear un programa con una clase Ordenador que permita modelar uno con
		 * características como capacidad de disco duro, frecuencia del procesador,
		 * precio base y marca. Crear dos clases hijas, llamadas Sobremesa y Portátil.
		 * Añadir a Sobremesa el atributo precioMontaje y al portátil otro atributo que
		 * será un booleno por si se quiere o no seguro para la pantalla y otro con la
		 * cantidad a pagar por dicho seguro.
		 * 
		 * La clase madre debe tener un método para calcular el precio de venta al
		 * público aplicando un % de ganancia del vendedor al precio base. Este método
		 * se debe reescribir en las clases hijas sumando la cantidad adecuada en el
		 * caso del montaje o la cantidad del seguro solo si el cliente lo quiere
		 * contratar.
		 * 
		 * Crear un main sencillo (no es necesario crear menú) para comprobar todo,
		 * basta llamar a los métodos en orden adecuado y mostrar el resultado de los
		 * cálculos que hace cada uno, es decir, el precio de venta al público de un
		 * objeto de cada subtipo (uno de sobremesa y un portátil).
		 */

		double capDisco = 250, hzProc = 1600, precioBase = 1250;
		String marca = "HP";
		
		int op;
		double porcen, precioMontar, precioSeguro = 0;
		
		Sobremesa sbrm;
		Portatil port;
		
		System.out.println("Bienvenido al programa de los ordenadores.\n");
		
		System.out.println("Di el porcentaje que vas a ganar:");
		porcen = Leer.datoDouble();
		
		System.out.println("Pulsa 1 para montar un sobremesa y 2 para un portatil");
		op = Leer.datoInt();
		
		switch (op) {
		
			case 1:
		
				System.out.println("¿Cúanto costará montar el pc de sobremesa?");
				precioMontar = Leer.datoDouble();
				
				sbrm = new Sobremesa(capDisco, hzProc, precioBase, marca, precioMontar);
				
				System.out.println(sbrm.calcularPVP(porcen));
				
			break;	
			
			case 2:
				
				System.out.println("Pulse 1 si quiere el seguro de pantalla.");
				if (Leer.datoInt() == 1) {
					
					System.out.println("Introduzca el precio del seguro:");
					precioSeguro = Leer.datoDouble();
					
				}
				
				port = new Portatil(capDisco, hzProc, precioBase, marca, false, precioSeguro);
				
				port.calcularPVP(porcen);
				
			break;
		}
		
	}

}
