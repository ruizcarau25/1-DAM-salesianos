package ejercicio01;

public class Ordenador {

	private double capacidadDiscoDuro;
	private double frecuenciaProcesador;
	private double precioBase;
	private String marca;
	
	//-----Constructor-----
	
	public Ordenador(double capacidadDiscoDuro, double frecuenciaProcesador, double precioBase, String marca) {
		super();
		this.capacidadDiscoDuro = capacidadDiscoDuro;
		this.frecuenciaProcesador = frecuenciaProcesador;
		this.precioBase = precioBase;
		this.marca = marca;
	}

	//-----Métodos-----

	public double calcularPVP (double porcen) {
		
		int den = 100;
		
		return precioBase + precioBase*(porcen/den);
		
	}

	@Override
	public String toString() {
		return "Ordenador [capacidadDiscoDuro=" + capacidadDiscoDuro + ", frecuenciaProcesador=" + frecuenciaProcesador
				+ ", precioBase=" + precioBase + ", marca=" + marca + "]";
	}
	
	
	
}
