package ejercicio01;

public class Sobremesa extends Ordenador {

	private double precioMontaje;

	public Sobremesa(double capacidadDiscoDuro, double frecuenciaProcesador, double precioBase, String marca,
			double precioMontaje) {
		super(capacidadDiscoDuro, frecuenciaProcesador, precioBase, marca);
		this.precioMontaje = precioMontaje;
	}
	
	public double calcularPVP (double porcen) {
		
		return super.calcularPVP(porcen) + precioMontaje;
		
		
		
	}
	
}
