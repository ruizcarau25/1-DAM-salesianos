package ejercicio01;

public class Portatil extends Ordenador {

	private boolean seguroPantalla;
	private double precioSeguroPantalla;
	
	
	public Portatil(double capacidadDiscoDuro, double frecuenciaProcesador, double precioBase, String marca,
			boolean seguroPantalla, double precioSeguroPantalla) {
		super(capacidadDiscoDuro, frecuenciaProcesador, precioBase, marca);
		this.seguroPantalla = seguroPantalla;
		this.precioSeguroPantalla = precioSeguroPantalla;
	}
	
	public double calcularPVP (double porcen) {
		
		double pvp = super.calcularPVP(porcen);
	
		if (seguroPantalla) {
			
			pvp = pvp + precioSeguroPantalla;
			
		}
		
		return pvp;
		
	}
	
}
