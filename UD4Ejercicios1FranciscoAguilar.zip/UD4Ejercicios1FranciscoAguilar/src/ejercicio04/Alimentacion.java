package ejercicio04;

public class Alimentacion extends Producto {

	private int diasParaCaducado;
	
	//--Constructor--
	
	public Alimentacion(double precioUnitario, String nombre, int codigoIden, double descuento, int diasParaCaducado) {
		super(precioUnitario, nombre, codigoIden);
		this.diasParaCaducado = diasParaCaducado;
	}

	public Alimentacion(double precioUnitario, String nombre, int codigoIden) {
		super(precioUnitario, nombre, codigoIden);
	}

	//--Getters and setters--
	
	public int getDiasParaCaducado() {
		return diasParaCaducado;
	}

	public void setDiasParaCaducado(int diasParaCaducado) {
		this.diasParaCaducado = diasParaCaducado;
	}

	//--To String--
	
	@Override
	public String toString() {
		return super.toString() + " Alimentación [diasParaCaducado=" + diasParaCaducado + "]";
	}

	//--Métodos--
	
	@Override
	public double calcularPrecioFinal(double descuento) {
		
		if (aplicarDescuento()) {
			
			return getPrecioUnitario() - getPrecioUnitario()*descuento/100;
			
		} else {
			
			return getPrecioUnitario();
			
		}
		
		
	}

	public boolean aplicarDescuento () {
		
		if (diasParaCaducado <= 2) {
			
			return true;
			
		} else {
			
			return false;
			
		}
		
	}
	
	public void avisarDescuento () {
		
		if (aplicarDescuento()) {
			
			System.out.println("Al producto le quedan 2 o menos días para caducar.");
			
		}
		
	}
	
	
}
