package ejercicio04;

public class LineaDeVenta {

	private Producto p;
	private int cant;
	
	//--Constructor--
	
	public LineaDeVenta(Producto p, int cant) {
		
		this.p = p;
		this.cant = cant;
		
	}

	//--Getters and setters--
	
	public Producto getP() {
		return p;
	}

	public void setP(Producto p) {
		this.p = p;
	}

	public int getCant() {
		return cant;
	}

	public void setCant(int cant) {
		this.cant = cant;
	}

	
	//--To String--
	
	@Override
	public String toString() {
		return "LineaDeVenta [p=" + p + ", cant=" + cant + "]";
	}

	//--Métodos--
	
	public void mostrarLDV () {
		
		System.out.printf("%s\t\t%d\t%.2f\t%.2f\n", p.getNombre(), cant, p.calcularPrecioFinal(20),(p.calcularPrecioFinal(20)*cant));
		
	}
	
	
}
