package ejercicio04;

public class Venta {

	private LineaDeVenta [] ldv;

	//--Constructor--
	
	public Venta(LineaDeVenta[] ldv) {
		super();
		this.ldv = ldv;
	}
	
	//--Métodos--
	
	public double calcularTotal () {
		
		double total = 0;
		
		for (int i = 0; i < ldv.length && ldv[i] != null; i++) {
			
			total += ldv[i].getCant() * ldv[i].getP().calcularPrecioFinal(20);
			
		}
		
		return total;
	}
	
	public void mostrarProductos () {
		
		for (int i = 0; i < ldv.length && ldv[i] != null; i++) {
			
			System.out.println(ldv[i].toString()); 
			
			if ((ldv[i].getP()) instanceof Alimentacion) {
				
				if (((Alimentacion)ldv[i].getP()).aplicarDescuento()) {
					
					((Alimentacion)ldv[i].getP()).avisarDescuento();
					System.out.println();
					
				}
				
			}
			
		}
			
	}
	
	public void imprimirTicket () {
		
		System.out.println("-------------------------------------------------");
		System.out.println("\n\t\t    TIENDAS DAM     \n");
		System.out.println("-------------------------------------------------");
		System.out.println("Articulo\t\tUD\tPrecio\tImporte");
		System.out.println("-------------------------------------------------");
		
		for (int i = 0; i < ldv.length && ldv[i] != null; i++) {
			
			ldv[i].mostrarLDV();
		}
		
		System.out.println("-------------------------------------------------");
		System.out.printf("\t\t\t\tTOTAL:\t%.2f\n",calcularTotal());
		System.out.println("\n\n\t       GRACIAS POR SU COMPRA\n");
		System.out.println("-------------------------------------------------");
	}
	
	
	
}
