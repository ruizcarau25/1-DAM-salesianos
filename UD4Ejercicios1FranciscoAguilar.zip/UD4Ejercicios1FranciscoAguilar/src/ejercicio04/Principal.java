package ejercicio04;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {
		/*
		 * Hacer un programa que imprima un ticket de compra, basándonos en un
		 * supermercado. Debemos crear la clase Producto genérica y dos hijas con un
		 * atributo más cada una (Alimentación y Electrónica). Cada producto genérico
		 * deberá estar caracterizado por el precio unitario, nombre, código de
		 * identificación, etc. El precio de los productos de electrónica lleva un
		 * impuesto especial por ser de lujo y la alimentación un descuento cuando le
		 * quedan menos de 2 días para caducar. Crear la clase Línea de venta, con un
		 * producto y una cantidad como atributos y la clase Venta con un array de
		 * líneas de venta. 
		 * 
		 * El ticket debe mostrar una venta completa con varios
		 * productos y varias cantidades. Se pueden crear los productos directamente en
		 * el main antes de empezar. Agregar un método que solo estará en la clase
		 * alimentación, que avise si al producto le quedan menos de 2 días para
		 * caducar. 
		 * 
		 * Crear un main, donde crearemos directamente los objetos necesarios.
		 * Solo habrá la opción imprimir ticket y listar todos los productos guardados,
		 * avisando cuando a un producto de alimentación le falten menos de dos días
		 * para caducar. Se pueden crear más métodos si quieres entrenar.
		 */
		
		int op;
		
		Producto a1 = new Alimentacion(2, "Piruleta", 1, 20, 5);
		Producto a2 = new Alimentacion(10, "Empanada", 2, 20, 1);
		Producto e1 = new Electrónica(360, "Portátil", 3, 15);
		Producto e2 = new Electrónica(1000, "PC Gaming", 4, 30);
		
		LineaDeVenta [] ldv = new LineaDeVenta [4];
		
		ldv [0] = new LineaDeVenta(a1, 1);
		ldv [1] = new LineaDeVenta(a2, 3);
		ldv [2] = new LineaDeVenta(e1, 1);
		ldv [3] = new LineaDeVenta(e2, 2);
		
		Venta v = new Venta(ldv);
		
		
		
		System.out.println("Seleccione una opción:");
		
		do {
			
			System.out.println("\nPulse 1 - Mostrar todos los productos.");
			System.out.println("Pulse 2 - Mostrar ticket.");
			System.out.println("Pulse 0 - Cerrar programa.");
			op = Leer.datoInt();
			System.out.println();
			
			
			switch (op) {
			
				case 0:
				break;
			
				case 1:
					
					v.mostrarProductos();
					
				break;
				
				case 2:
					
					v.imprimirTicket();
					
				break;
				
				default:
					
					System.out.println("Debe elegir una opción válida.");
				
			}
			
			
		} while (op != 0);
		
		System.out.println("-----Gracias por usar este programa-----");
		
	}

}
