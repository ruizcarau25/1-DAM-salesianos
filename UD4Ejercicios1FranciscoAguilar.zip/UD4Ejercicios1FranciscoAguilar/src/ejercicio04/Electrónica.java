package ejercicio04;

public class Electrónica extends Producto{

	private double impuesto;

	//--Constructor--
	
	public Electrónica(double precioUnitario, String nombre, int codigoIden, double impuesto) {
		super(precioUnitario, nombre, codigoIden);
		this.impuesto = impuesto;
	}
	
	public Electrónica(double precioUnitario, String nombre, int codigoIden) {
		super(precioUnitario, nombre, codigoIden);
	}
	
	//--Getters and setters--
	
	public double getImpuesto() {
		return impuesto;
	}

	public void setImpuesto(double impuesto) {
		this.impuesto = impuesto;
	}

	//--To String--
	
	@Override
	public String toString() {
		return super.toString() + " Electrónica [impuesto=" + impuesto + "]";
	}

	//--Métodos--
	
	@Override
	public double calcularPrecioFinal(double descuento) {
		
		return getPrecioUnitario() + getPrecioUnitario()*impuesto/100;
	}

}
