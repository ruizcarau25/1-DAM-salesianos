package ejercicio02;

public class TarjetaVisita extends Documento{

	private Trabajador trab;

	public TarjetaVisita(String nombreEmpresa, String ubiEmpresa, String infoEmpresa, Trabajador trab) {
		super(nombreEmpresa, ubiEmpresa, infoEmpresa);
		this.trab = trab;
	}

	public void imprimirCabecera () {
		
		super.imprimirCabecera();
		System.out.printf("\n\n%s %s\t\t\tDepartamento: %s", trab.getNombre(), trab.getApellido(), trab.getDepartamento());
	}
	
	
}
