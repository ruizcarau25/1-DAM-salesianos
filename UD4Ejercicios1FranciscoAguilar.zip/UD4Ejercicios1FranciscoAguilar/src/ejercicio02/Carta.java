package ejercicio02;

public class Carta extends Documento {

	private String fecha;

	public Carta(String nombreEmpresa, String ubiEmpresa, String infoEmpresa, String fecha) {
		
		super(nombreEmpresa, ubiEmpresa, infoEmpresa);
		this.fecha = fecha;
		
	}
	
	public void imprimirCabecera () {
		
		super.imprimirCabecera();
		System.out.println();
		System.out.printf("\n\t\t\t\t%s", fecha);
	}
	
}
