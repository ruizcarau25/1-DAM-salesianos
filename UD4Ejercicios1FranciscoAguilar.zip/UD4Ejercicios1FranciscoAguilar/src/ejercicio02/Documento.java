package ejercicio02;

public class Documento {

	private String nombreEmpresa;
	private String ubiEmpresa;
	private String infoEmpresa;
	
	public Documento(String nombreEmpresa, String ubiEmpresa, String infoEmpresa) {
		super();
		this.nombreEmpresa = nombreEmpresa;
		this.ubiEmpresa = ubiEmpresa;
		this.infoEmpresa = infoEmpresa;
	}

	@Override
	public String toString() {
		return "Documento [nombreEmpresa=" + nombreEmpresa + ", ubiEmpresa=" + ubiEmpresa + ", infoEmpresa="
				+ infoEmpresa + "]";
	}
	
	public void imprimirCabecera () {
		
		System.out.printf("%s\t\t\t\t%s\n", nombreEmpresa, infoEmpresa);
		System.out.printf("%s", ubiEmpresa);
		
	}
	
}
