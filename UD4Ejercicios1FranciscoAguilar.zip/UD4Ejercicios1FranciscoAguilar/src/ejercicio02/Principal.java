package ejercicio02;

import utilidades.Leer;

public class Principal {

	public static void main(String[] args) {
		
		/*
		 * Escribir un programa que tenga una clase Documento y dos clases hijas, Tarjeta de visita y Carta.
			Crear los métodos necesarios para que, la cabecera de cada tipo de documento se imprima en pantalla
			de una forma diferente, según sus características. Como es un ejemplo académico, podemos hacer los
			métodos de impresión dentro de cada clase. Por ejemplo, el documento genérico solo tiene un pequeño
			encabezado con los datos de la empresa, la tarjeta puede llevar, además, los datos de contacto de una
			persona y la carta, una fecha.

			Crear un main para hacer una prueba con cada método llamado con objetos de las distintas clases.
		 */

		int op;
		
		String nombreEmpresa, nombreUbi, nombreExtra;
		String nombreTrab, apellidoTrab, departTrab;
		String fecha;
		
		Documento doc;
		TarjetaVisita tarjVis;
		Carta cart;
		Trabajador trab;
		
		System.out.println("Bienvenido al generador de cabeceras de la empresa.\n");
		
		System.out.println("En primer lugar indique algunos datos básicos.");
		System.out.println("Introduzca el nombre de la empresa:");
		nombreEmpresa = Leer.dato();
		System.out.println("Introduzca la ubicación/sector donde se ubica de la empresa:");
		nombreUbi =Leer.dato();
		System.out.println("Introduzca un dato extra para la parte derecha de la cabecera (pulse espacio si no quiere nada)");
		nombreExtra = Leer.dato();
		
		doc = new Documento(nombreEmpresa, nombreUbi, nombreExtra);
		
		
		
		do {
		
			System.out.println("\nA continuación indique el tipo de cabecera que quiere generar:");
			System.out.println("Pulse 1 - Cabecera estándar");
			System.out.println("Pulse 2 - Cabecera de tarjeta de visita");
			System.out.println("Pulse 3 - Cabecera de carta");
			System.out.println("Pulse 0 - Cerrar programa");
			op = Leer.datoInt();
			System.out.println();
			
			switch (op) {
			
				case 1:
					
					doc.imprimirCabecera();
				
				break;
			
				case 2:
					
					System.out.println("Antes de continuar debe introducir los datos del trabajador:");
					System.out.println("Introduzca el nombre del trabajador:");
					nombreTrab = Leer.dato();
					System.out.println("Introduzca el apellido del trabajador:");
					apellidoTrab = Leer.dato();
					System.out.println("Introduzca el departamento del trabajador:");
					departTrab = Leer.dato();
					
					trab = new Trabajador(nombreTrab, apellidoTrab, departTrab);
					tarjVis = new TarjetaVisita(nombreEmpresa, nombreUbi, nombreExtra, trab);
					
					System.out.println("Su cabecerá se generará a continuación:\n\n");
					
					tarjVis.imprimirCabecera();
					
				break;
				
				case 3:
					
					System.out.println("Antes de continuar debe indicar la fecha que aparecerá en la carta. Se recomienda el formato dd/mm/aaaa");
					fecha = Leer.dato();
					
					cart = new Carta(nombreEmpresa, nombreUbi, nombreExtra, fecha);
					
					System.out.println("Su cabecerá se generará a continuación:\n\n");
					
					cart.imprimirCabecera();
					
				break;
			}
			
			System.out.println("\n\nPulse 0 para cerrar el programa u otro número para generar una nueva cabecera:");
			op = Leer.datoInt();
		
		} while (op != 0);
		
		System.out.println("-----Gracias por usar este programa-----");
		
	}

}
